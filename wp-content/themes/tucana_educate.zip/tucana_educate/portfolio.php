<?php 
/**
 * 	Template Name:	Portfolio Template
 */
    get_header();
    do_action('modal');
    do_action('portfolio');
    
    get_footer(); 
?>            
