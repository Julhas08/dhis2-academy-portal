<?php
/**
 * 	Template Name:	Product
 */
	get_header();
	do_action('product');
	get_footer();	
?>