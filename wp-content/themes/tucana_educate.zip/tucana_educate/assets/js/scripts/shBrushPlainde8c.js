SyntaxHighlighter.brushes.Plain=function()
{};SyntaxHighlighter.brushes.Plain.prototype=new SyntaxHighlighter.Highlighter();SyntaxHighlighter.brushes.Plain.aliases=['text','plain'];